# Add project specific ProGuard rules here.
# Minification is disabled in app/build.gradle, so this file is currently unused.
