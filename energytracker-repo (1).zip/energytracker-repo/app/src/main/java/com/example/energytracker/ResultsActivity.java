package com.example.energytracker;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class ResultsActivity extends AppCompatActivity {

    private TextView tvApplianceName, tvCategory, tvDailyConsumption,
            tvMonthlyConsumption, tvMonthlyCost, tvEnergyRating, tvRecommendation;
    private Button btnCalculateAgain, btnHome, btnExitResults;

    private DatabaseHelper databaseHelper;
    private long reportId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);

        tvApplianceName = findViewById(R.id.tvApplianceName);
        tvCategory = findViewById(R.id.tvCategory);
        tvDailyConsumption = findViewById(R.id.tvDailyConsumption);
        tvMonthlyConsumption = findViewById(R.id.tvMonthlyConsumption);
        tvMonthlyCost = findViewById(R.id.tvMonthlyCost);
        tvEnergyRating = findViewById(R.id.tvEnergyRating);
        tvRecommendation = findViewById(R.id.tvRecommendation);

        btnCalculateAgain = findViewById(R.id.btnCalculateAgain);
        btnHome = findViewById(R.id.btnHome);
        btnExitResults = findViewById(R.id.btnExitResults);

        databaseHelper = new DatabaseHelper(this);
        reportId = getIntent().getLongExtra("REPORT_ID", -1);

        if (reportId == -1) {
            Toast.makeText(this, "No report was found to display", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        displaySavedReport();

        btnCalculateAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ResultsActivity.this, InputActivity.class));
                finish();
            }
        });

        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ResultsActivity.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });

        btnExitResults.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finishAffinity();
            }
        });
    }

    private void displaySavedReport() {

        Cursor cursor = databaseHelper.getReportById(reportId);

        if (cursor != null && cursor.moveToFirst()) {

            String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_NAME));
            String category = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_CATEGORY));
            double daily = cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_DAILY));
            double monthly = cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_MONTHLY));
            double cost = cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_COST));
            String rating = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_RATING));
            String advice = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ADVICE));

            cursor.close();

            tvApplianceName.setText(name);
            tvCategory.setText(category);
            tvDailyConsumption.setText(String.format(Locale.getDefault(), "%.2f kWh", daily));
            tvMonthlyConsumption.setText(String.format(Locale.getDefault(), "%.2f kWh", monthly));
            tvMonthlyCost.setText(String.format(Locale.getDefault(), "R%.2f", cost));

            tvEnergyRating.setText(rating != null ? rating : "-");
            tvRecommendation.setText(advice != null ? advice : "-");

        } else {
            if (cursor != null) cursor.close();
            Toast.makeText(this, "The saved report could not be read", Toast.LENGTH_LONG).show();
            finish();
        }
    }
}
