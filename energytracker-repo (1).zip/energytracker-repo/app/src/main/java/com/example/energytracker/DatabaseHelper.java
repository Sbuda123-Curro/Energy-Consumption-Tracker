package com.example.energytracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "energy_tracker.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_REPORTS = "energy_reports";

    public static final String COL_ID = "id";
    public static final String COL_NAME = "appliance_name";
    public static final String COL_CATEGORY = "category";
    public static final String COL_POWER = "power_rating";
    public static final String COL_HOURS = "usage_hours";
    public static final String COL_TARIFF = "tariff";
    public static final String COL_DAILY = "daily_consumption";
    public static final String COL_MONTHLY = "monthly_consumption";
    public static final String COL_COST = "monthly_cost";
    public static final String COL_RATING = "energy_rating";
    public static final String COL_ADVICE = "recommendation";
    public static final String COL_DATE = "date_created";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_REPORTS + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_NAME + " TEXT NOT NULL, " +
                COL_CATEGORY + " TEXT NOT NULL, " +
                COL_POWER + " REAL NOT NULL, " +
                COL_HOURS + " REAL NOT NULL, " +
                COL_TARIFF + " REAL NOT NULL, " +
                COL_DAILY + " REAL NOT NULL, " +
                COL_MONTHLY + " REAL NOT NULL, " +
                COL_COST + " REAL NOT NULL, " +
                COL_RATING + " TEXT, " +
                COL_ADVICE + " TEXT, " +
                COL_DATE + " TEXT NOT NULL)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Simple coursework approach: a schema change recreates the table and clears saved reports.
        // A production app would migrate the existing data instead.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_REPORTS);
        onCreate(db);
    }

    public long insertReport(Appliance appliance, double daily, double monthly, double cost,
                             String rating, String advice) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_NAME, appliance.getName());
        values.put(COL_CATEGORY, appliance.getCategory());
        values.put(COL_POWER, appliance.getPowerRating());
        values.put(COL_HOURS, appliance.getUsageHours());
        values.put(COL_TARIFF, appliance.getTariff());
        values.put(COL_DAILY, daily);
        values.put(COL_MONTHLY, monthly);
        values.put(COL_COST, cost);
        values.put(COL_RATING, rating);
        values.put(COL_ADVICE, advice);
        values.put(COL_DATE, currentDate());

        long newRowId = db.insert(TABLE_REPORTS, null, values);
        db.close();
        return newRowId;
    }

    public Cursor getReportById(long reportId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_REPORTS, null, COL_ID + " = ?",
                new String[]{String.valueOf(reportId)}, null, null, null);
    }

    public ArrayList<String> getAllReports() {
        ArrayList<String> reports = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_REPORTS, null, null, null, null, null,
                COL_ID + " DESC");

        if (cursor != null && cursor.moveToFirst()) {
            do {
                String name = cursor.getString(cursor.getColumnIndexOrThrow(COL_NAME));
                String category = cursor.getString(cursor.getColumnIndexOrThrow(COL_CATEGORY));
                double daily = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_DAILY));
                double monthly = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_MONTHLY));
                double cost = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_COST));
                String rating = cursor.getString(cursor.getColumnIndexOrThrow(COL_RATING));
                String advice = cursor.getString(cursor.getColumnIndexOrThrow(COL_ADVICE));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(COL_DATE));

                if (rating == null) rating = "-";
                if (advice == null) advice = "-";

                String entry = name + "  (" + category + ")\n" +
                        "Daily: " + String.format(Locale.getDefault(), "%.2f", daily) + " kWh\n" +
                        "Monthly: " + String.format(Locale.getDefault(), "%.2f", monthly) + " kWh\n" +
                        "Cost: R" + String.format(Locale.getDefault(), "%.2f", cost) + "\n" +
                        "Rating: " + rating + "\n" +
                        "Advice: " + advice + "\n" +
                        "Saved: " + date;

                reports.add(entry);
            } while (cursor.moveToNext());
        }

        if (cursor != null) cursor.close();
        db.close();
        return reports;
    }

    private String currentDate() {
        SimpleDateFormat formatter = new SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault());
        return formatter.format(new Date());
    }
}
