package com.example.energytracker;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class HistoryActivity extends AppCompatActivity {

    private ListView lvReports;
    private TextView tvEmpty;
    private Button btnBack;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        lvReports = findViewById(R.id.lvReports);
        tvEmpty = findViewById(R.id.tvEmpty);
        btnBack = findViewById(R.id.btnBack);

        databaseHelper = new DatabaseHelper(this);

        loadReports();

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void loadReports() {
        ArrayList<String> reports = databaseHelper.getAllReports();

        if (reports.isEmpty()) {
            tvEmpty.setVisibility(View.VISIBLE);
            lvReports.setVisibility(View.GONE);
        } else {
            tvEmpty.setVisibility(View.GONE);
            lvReports.setVisibility(View.VISIBLE);

            ArrayAdapter<String> adapter = new ArrayAdapter<>(
                    this, R.layout.item_report, R.id.tvReportItem, reports);
            lvReports.setAdapter(adapter);
        }
    }
}
