package com.example.energytracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class InputActivity extends AppCompatActivity {

    private EditText etApplianceName, etPowerRating, etUsageHours, etTariff;
    private Spinner spinnerCategory;
    private Button btnCalculate, btnClear;

    private DatabaseHelper databaseHelper;
    private ElectricityCalculator calculator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input);

        etApplianceName = findViewById(R.id.etApplianceName);
        etPowerRating = findViewById(R.id.etPowerRating);
        etUsageHours = findViewById(R.id.etUsageHours);
        etTariff = findViewById(R.id.etTariff);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        btnCalculate = findViewById(R.id.btnCalculate);
        btnClear = findViewById(R.id.btnClear);

        databaseHelper = new DatabaseHelper(this);
        calculator = new ElectricityCalculator();

        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculateAndSave();
            }
        });

        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clearFields();
            }
        });
    }

    private boolean validateInput() {
        boolean isValid = true;

        String name = etApplianceName.getText().toString().trim();
        String power = cleanNumber(etPowerRating);
        String hours = cleanNumber(etUsageHours);
        String tariff = cleanNumber(etTariff);

        if (name.isEmpty()) {
            etApplianceName.setError("Appliance name is required");
            isValid = false;
        }

        if (power.isEmpty()) {
            etPowerRating.setError("Power rating is required");
            isValid = false;
        } else if (!isNumeric(power)) {
            etPowerRating.setError("Enter a valid number");
            isValid = false;
        } else if (Double.parseDouble(power) <= 0) {
            etPowerRating.setError("Must be greater than zero");
            isValid = false;
        }

        if (hours.isEmpty()) {
            etUsageHours.setError("Daily usage hours is required");
            isValid = false;
        } else if (!isNumeric(hours)) {
            etUsageHours.setError("Enter a valid number");
            isValid = false;
        } else {
            double hoursValue = Double.parseDouble(hours);
            if (hoursValue <= 0 || hoursValue > 24) {
                etUsageHours.setError("Must be between 0 and 24");
                isValid = false;
            }
        }

        if (tariff.isEmpty()) {
            etTariff.setError("Tariff is required");
            isValid = false;
        } else if (!isNumeric(tariff)) {
            etTariff.setError("Enter a valid number");
            isValid = false;
        } else if (Double.parseDouble(tariff) <= 0) {
            etTariff.setError("Must be greater than zero");
            isValid = false;
        }

        if (!isValid) {
            Toast.makeText(this, "Please correct the highlighted fields",
                    Toast.LENGTH_SHORT).show();
        }

        return isValid;
    }

    /**
     * Reads a numeric field and accepts a comma as the decimal separator,
     * because some South African keyboards type "2,50" instead of "2.50".
     */
    private String cleanNumber(EditText field) {
        return field.getText().toString().trim().replace(',', '.');
    }

    private boolean isNumeric(String value) {
        try {
            Double.parseDouble(value);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private void calculateAndSave() {

        if (!validateInput()) {
            return;
        }

        Appliance appliance = new Appliance();
        appliance.setName(etApplianceName.getText().toString().trim());
        appliance.setCategory(spinnerCategory.getSelectedItem().toString());
        appliance.setPowerRating(Double.parseDouble(cleanNumber(etPowerRating)));
        appliance.setUsageHours(Double.parseDouble(cleanNumber(etUsageHours)));
        appliance.setTariff(Double.parseDouble(cleanNumber(etTariff)));

        double daily = calculator.calculateDailyConsumption(
                appliance.getPowerRating(), appliance.getUsageHours());
        double monthly = calculator.calculateMonthlyConsumption(daily);
        double cost = calculator.calculateMonthlyCost(monthly, appliance.getTariff());

        Recommendation recommendation = new Recommendation();
        String rating = recommendation.getEnergyEfficiencyCategory(monthly);
        String advice = recommendation.getRecommendation(rating);

        long reportId = databaseHelper.insertReport(appliance, daily, monthly, cost, rating, advice);

        if (reportId == -1) {
            Toast.makeText(this, "The report could not be saved", Toast.LENGTH_LONG).show();
            return;
        }

        Toast.makeText(this, "Report saved", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(InputActivity.this, ResultsActivity.class);
        intent.putExtra("REPORT_ID", reportId);
        startActivity(intent);
    }

    private void clearFields() {
        etApplianceName.setText("");
        etPowerRating.setText("");
        etUsageHours.setText("");
        etTariff.setText("");
        spinnerCategory.setSelection(0);
        etApplianceName.requestFocus();
    }
}
