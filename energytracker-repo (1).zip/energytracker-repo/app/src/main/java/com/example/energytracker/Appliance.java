package com.example.energytracker;

public class Appliance {

    private String name;
    private double powerRating;
    private double usageHours;
    private double tariff;
    private String category;

    public Appliance() {
        this.name = "";
        this.powerRating = 0.0;
        this.usageHours = 0.0;
        this.tariff = 0.0;
        this.category = "";
    }

    public Appliance(String name, double powerRating, double usageHours,
                     double tariff, String category) {
        this.name = name;
        this.powerRating = powerRating;
        this.usageHours = usageHours;
        this.tariff = tariff;
        this.category = category;
    }

    public String getName() {
        return name;
    }

    public double getPowerRating() {
        return powerRating;
    }

    public double getUsageHours() {
        return usageHours;
    }

    public double getTariff() {
        return tariff;
    }

    public String getCategory() {
        return category;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPowerRating(double powerRating) {
        this.powerRating = powerRating;
    }

    public void setUsageHours(double usageHours) {
        this.usageHours = usageHours;
    }

    public void setTariff(double tariff) {
        this.tariff = tariff;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
