package com.example.energytracker;

public class Recommendation {

    public static final String EXCELLENT = "Excellent";
    public static final String GOOD = "Good";
    public static final String AVERAGE = "Average";
    public static final String HIGH = "High Consumption";
    public static final String VERY_HIGH = "Very High Consumption";

    public String getEnergyEfficiencyCategory(double monthlyConsumption) {
        String category;

        if (monthlyConsumption < 150) {
            category = EXCELLENT;
        } else if (monthlyConsumption < 300) {
            category = GOOD;
        } else if (monthlyConsumption < 500) {
            category = AVERAGE;
        } else if (monthlyConsumption < 700) {
            category = HIGH;
        } else {
            category = VERY_HIGH;
        }

        return category;
    }

    public String getRecommendation(String energyCategory) {
        String advice;

        if (EXCELLENT.equals(energyCategory)) {
            advice = "Continue maintaining your current electricity usage.";
        } else if (GOOD.equals(energyCategory)) {
            advice = "Consider switching to LED lighting.";
        } else if (AVERAGE.equals(energyCategory)) {
            advice = "Reduce appliance usage during peak hours.";
        } else if (HIGH.equals(energyCategory)) {
            advice = "Replace old appliances with energy-efficient models.";
        } else {
            advice = "Immediate action is recommended to reduce electricity usage.";
        }

        return advice;
    }
}
