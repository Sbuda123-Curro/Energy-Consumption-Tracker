package com.example.energytracker;

public class ElectricityCalculator {

    public static final int DAYS_IN_MONTH = 30;
    public static final double WATTS_IN_A_KILOWATT = 1000.0;

    public double calculateDailyConsumption(double powerRating, double usageHours) {
        return (powerRating * usageHours) / WATTS_IN_A_KILOWATT;
    }

    public double calculateMonthlyConsumption(double dailyConsumption) {
        return dailyConsumption * DAYS_IN_MONTH;
    }

    public double calculateMonthlyCost(double monthlyConsumption, double tariff) {
        return monthlyConsumption * tariff;
    }
}
